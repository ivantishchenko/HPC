Find the sources int the src/

pi_1.c - sequantial pi computation
pi_2.c - mpi pi computation
pi_3.c - mpi pi computation + time(data.txt)

sim_1.c - sequantial Simpson pi computation
sim_2.c - mpi Simpson pi computation
sim_3.c - mpi Simpson pi computation + time(data.txt)

sim_1.c - sequantial Monte Carlo pi computation
sim_2.c - sequantial Monte Carlo pi computation + plotting the points inside and out
sim_3.c - mpi Monte Carlo pi computation
sim_4.c - mpi Monte Carlo pi computation + time(data.txt) AT LEAST 2 Processes

find the files with the the meassurement with the different number of processors in various data.txt